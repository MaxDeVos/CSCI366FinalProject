﻿namespace CSCI366FinalProject
{


    partial class FinalAssignmentDatabaseDataSet
    {
        partial class game_listDataTable
        {
        }

        partial class playerDataTable
        {
        }

        partial class team_gameDataTable
        {
        }

        partial class locationDataTable
        {
        }
    }
}

namespace CSCI366FinalProject.FinalAssignmentDatabaseDataSetTableAdapters
{
    partial class game_listTableAdapter
    {
    }

    partial class playersUITableAdapter
    {
    }

    public partial class playerTableAdapter {
    }
}
